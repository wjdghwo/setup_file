.. vim: set fileencoding=utf-8 :


=======================
 Bob
=======================

Bob_ is a free signal-processing and machine learning toolbox originally
developed by the Biometrics group at `Idiap`_ Research Institute, Switzerland.

The documentation of Bob has moved. Please visit https://www.idiap.ch/software/bob for
up-to-date links.

.. _idiap: http://www.idiap.ch

            x = np.arange(len(y)))
    parse(np.ones((5, 5, 5))) # exception
            raise ValueError(f'y is expected to be 1 or 2 dimensional, got {len(y.shape)} instead')


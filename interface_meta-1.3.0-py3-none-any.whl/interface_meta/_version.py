__author__ = "Matthew Wardrop"
__author_email__ = "mpwardrop@gmail.com"
__version__ = "1.3.0"

__dependencies__ = []

.. _sklearn-crfsuite-tutorial:

.. note::

    This tutorial can be run as an IPython notebook_.

.. _notebook: https://github.com/TeamHG-Memex/eli5/blob/master/notebooks/sklearn-crfsuite.ipynb

.. include:: ../_notebooks/debug-sklearn-crfsuite.rst

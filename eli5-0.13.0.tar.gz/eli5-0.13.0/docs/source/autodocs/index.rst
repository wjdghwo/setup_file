API
===

API documentation is auto-generated.

.. toctree::
   :maxdepth: 2

   ./eli5
   ./formatters
   ./lightning
   ./lime
   ./sklearn
   ./sklearn_crfsuite
   ./xgboost
   ./lightgbm
   ./catboost
   ./permutation_importance
   ./keras
   ./base
   


Normalize(SparseDecomp(SparseMatrixCOO(['item', 'user'])))


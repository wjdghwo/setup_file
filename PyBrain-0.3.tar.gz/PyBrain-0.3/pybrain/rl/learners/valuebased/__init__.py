from interface import ActionValueTable, ActionValueNetwork
from nfq import NFQ
from q import Q
from qlambda import QLambda
from sarsa import SARSA
from tiger import TigerTask
from maze import TrivialMaze, MazeTask
from cheesemaze import CheeseMaze
from tmaze import TMaze
from maze4x3 import FourByThreeMaze
from maze89state import EightyNineStateMaze
from shuttle import ShuttleDocking
from mdp import MDPMazeTask

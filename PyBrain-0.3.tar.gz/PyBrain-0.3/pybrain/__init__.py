from structure.__init__ import *

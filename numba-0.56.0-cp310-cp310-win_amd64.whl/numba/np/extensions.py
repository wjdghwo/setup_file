"""
NumPy extensions.
"""

from numba.np.arraymath import cross2d


__all__ = [
    'cross2d'
]

def identity(data):
    return data
